import { teamInvitationsCrudHandlers } from "../crud";

export const DELETE = teamInvitationsCrudHandlers.deleteHandler;
