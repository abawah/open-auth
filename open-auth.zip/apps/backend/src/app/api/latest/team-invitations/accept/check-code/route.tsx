import { teamInvitationCodeHandler } from "../verification-code-handler";

export const POST = teamInvitationCodeHandler.checkHandler;
