import { teamInvitationsCrudHandlers } from "./crud";

export const GET = teamInvitationsCrudHandlers.listHandler;
