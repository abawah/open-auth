import { connectedAccountAccessTokenCrudHandlers } from "./crud";

export const POST = connectedAccountAccessTokenCrudHandlers.createHandler;
