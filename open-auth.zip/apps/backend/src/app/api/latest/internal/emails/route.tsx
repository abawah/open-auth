import { internalEmailsCrudHandlers } from "./crud";

export const GET = internalEmailsCrudHandlers.listHandler;
