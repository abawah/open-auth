import { internalProjectsCrudHandlers } from "./crud";

export const GET = internalProjectsCrudHandlers.listHandler;
export const POST = internalProjectsCrudHandlers.createHandler;
