import { emailTemplateCrudHandlers } from "./crud";

export const GET = emailTemplateCrudHandlers.listHandler;
