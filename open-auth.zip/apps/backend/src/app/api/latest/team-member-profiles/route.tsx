import { teamMemberProfilesCrudHandlers } from "./crud";

export const GET = teamMemberProfilesCrudHandlers.listHandler;
