import { teamMemberProfilesCrudHandlers } from "../../crud";

export const GET = teamMemberProfilesCrudHandlers.readHandler;
export const PATCH = teamMemberProfilesCrudHandlers.updateHandler;
