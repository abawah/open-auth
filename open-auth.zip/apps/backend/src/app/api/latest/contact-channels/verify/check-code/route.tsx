import { contactChannelVerificationCodeHandler } from "../verification-code-handler";

export const POST = contactChannelVerificationCodeHandler.checkHandler;
