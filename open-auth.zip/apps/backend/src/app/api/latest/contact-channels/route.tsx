import { contactChannelsCrudHandlers } from "./crud";

export const POST = contactChannelsCrudHandlers.createHandler;
export const GET = contactChannelsCrudHandlers.listHandler;
