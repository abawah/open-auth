import { teamPermissionDefinitionsCrudHandlers } from "./crud";

export const POST = teamPermissionDefinitionsCrudHandlers.createHandler;
export const GET = teamPermissionDefinitionsCrudHandlers.listHandler;
