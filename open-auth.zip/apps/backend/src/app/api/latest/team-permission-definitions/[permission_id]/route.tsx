import { teamPermissionDefinitionsCrudHandlers } from "../crud";

export const PATCH = teamPermissionDefinitionsCrudHandlers.updateHandler;
export const DELETE = teamPermissionDefinitionsCrudHandlers.deleteHandler;
