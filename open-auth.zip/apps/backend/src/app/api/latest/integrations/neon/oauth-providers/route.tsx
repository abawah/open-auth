import { oauthProvidersCrudHandlers } from "./crud";

export const POST = oauthProvidersCrudHandlers.createHandler;
export const GET = oauthProvidersCrudHandlers.listHandler;
