import { POST as initiateTransfer } from "../route";

export const POST = initiateTransfer;
