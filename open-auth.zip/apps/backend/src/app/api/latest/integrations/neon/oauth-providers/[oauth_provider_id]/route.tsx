import { oauthProvidersCrudHandlers } from "../crud";

export const PATCH = oauthProvidersCrudHandlers.updateHandler;
export const DELETE = oauthProvidersCrudHandlers.deleteHandler;
