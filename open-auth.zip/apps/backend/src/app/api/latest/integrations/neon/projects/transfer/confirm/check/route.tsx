import { neonIntegrationProjectTransferCodeHandler } from "../verification-code-handler";

export const POST = neonIntegrationProjectTransferCodeHandler.checkHandler;
