import { domainCrudHandlers } from "../crud";

export const DELETE = domainCrudHandlers.deleteHandler;
