import { apiKeyCrudHandlers } from "../crud";

export const GET = apiKeyCrudHandlers.readHandler;
export const PATCH = apiKeyCrudHandlers.updateHandler;
