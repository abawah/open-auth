import { domainCrudHandlers } from "./crud";

export const GET = domainCrudHandlers.listHandler;
export const POST = domainCrudHandlers.createHandler;
