import { teamsCrudHandlers } from "./crud";

export const GET = teamsCrudHandlers.listHandler;
export const POST = teamsCrudHandlers.createHandler;
