import { signInVerificationCodeHandler } from "../verification-code-handler";

export const POST = signInVerificationCodeHandler.checkHandler;
