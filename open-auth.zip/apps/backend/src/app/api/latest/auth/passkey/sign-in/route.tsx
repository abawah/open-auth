import { passkeySignInVerificationCodeHandler } from "./verification-code-handler";

export const POST = passkeySignInVerificationCodeHandler.postHandler;
