import { sessionsCrudHandlers } from "../crud";

export const DELETE = sessionsCrudHandlers.deleteHandler;
