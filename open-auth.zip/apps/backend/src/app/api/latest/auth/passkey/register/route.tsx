import { registerVerificationCodeHandler } from "./verification-code-handler";

export const POST = registerVerificationCodeHandler.postHandler;
