import { mfaVerificationCodeHandler } from "./verification-code-handler";

export const POST = mfaVerificationCodeHandler.postHandler;
