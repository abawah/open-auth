import { resetPasswordVerificationCodeHandler } from "./verification-code-handler";

export const POST = resetPasswordVerificationCodeHandler.postHandler;
