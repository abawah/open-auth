import { teamPermissionsCrudHandlers } from "./crud";

export const GET = teamPermissionsCrudHandlers.listHandler;
