import { usersCrudHandlers } from "./crud";

export const GET = usersCrudHandlers.listHandler;
export const POST = usersCrudHandlers.createHandler;
