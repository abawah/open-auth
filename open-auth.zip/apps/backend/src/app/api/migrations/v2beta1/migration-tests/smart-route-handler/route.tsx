import { NotFoundHandler } from "@/route-handlers/not-found-handler";

export const GET = NotFoundHandler;
