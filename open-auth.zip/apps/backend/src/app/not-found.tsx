export default function NotFound() {
  return "Not Found";
}
