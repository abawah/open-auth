-- AlterEnum
ALTER TYPE "StandardOAuthProviderType" ADD VALUE 'LINKEDIN';
