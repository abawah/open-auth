-- AlterTable
ALTER TABLE "StandardOAuthProviderConfig" ADD COLUMN     "microsoftTenantId" TEXT;
