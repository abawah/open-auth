-- AlterTable
ALTER TABLE "VerificationCode" ADD COLUMN     "attemptCount" INTEGER NOT NULL DEFAULT 0;
