-- AlterEnum
ALTER TYPE "ProxiedOAuthProviderType" ADD VALUE 'SPOTIFY';

-- AlterEnum
ALTER TYPE "StandardOAuthProviderType" ADD VALUE 'SPOTIFY';
