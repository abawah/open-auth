-- AlterTable
ALTER TABLE "Team" ADD COLUMN     "profileImageUrl" TEXT;
