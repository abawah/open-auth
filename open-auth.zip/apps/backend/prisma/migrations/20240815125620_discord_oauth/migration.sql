-- AlterEnum
ALTER TYPE "StandardOAuthProviderType" ADD VALUE 'DISCORD';
