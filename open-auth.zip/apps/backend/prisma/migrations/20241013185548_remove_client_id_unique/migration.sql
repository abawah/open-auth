-- DropIndex
DROP INDEX "StandardOAuthProviderConfig_projectConfigId_clientId_key";
