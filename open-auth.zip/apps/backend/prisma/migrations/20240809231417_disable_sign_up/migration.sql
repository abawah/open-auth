-- AlterTable
ALTER TABLE "ProjectConfig" ADD COLUMN     "signUpEnabled" BOOLEAN NOT NULL DEFAULT true;
