-- AlterEnum
ALTER TYPE "StandardOAuthProviderType" ADD VALUE 'GITLAB';
