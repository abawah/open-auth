-- AlterEnum
ALTER TYPE "VerificationCodeType" ADD VALUE 'PASSWORD_RESET';
