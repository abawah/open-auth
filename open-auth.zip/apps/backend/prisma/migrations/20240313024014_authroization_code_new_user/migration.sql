-- AlterTable
ALTER TABLE "ProjectUserAuthorizationCode" ADD COLUMN     "newUser" BOOLEAN NOT NULL DEFAULT false;
