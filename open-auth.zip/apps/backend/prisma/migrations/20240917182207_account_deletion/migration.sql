-- AlterTable
ALTER TABLE "ProjectConfig" ADD COLUMN     "clientUserDeletionEnabled" BOOLEAN NOT NULL DEFAULT false;
