-- AlterEnum
ALTER TYPE "EmailTemplateType" ADD VALUE 'TEAM_INVITATION';

-- AlterEnum
ALTER TYPE "VerificationCodeType" ADD VALUE 'TEAM_INVITATION';
