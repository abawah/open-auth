-- AlterTable
ALTER TABLE "StandardOAuthProviderConfig" ADD COLUMN     "facebookConfigId" TEXT;
