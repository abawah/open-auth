-- AlterTable
ALTER TABLE "TeamMember" ADD COLUMN     "displayName" TEXT,
ADD COLUMN     "profileImageUrl" TEXT;
