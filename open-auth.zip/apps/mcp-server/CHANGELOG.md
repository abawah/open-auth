# @stackframe/mcp-server

## 2.7.27

initial release
