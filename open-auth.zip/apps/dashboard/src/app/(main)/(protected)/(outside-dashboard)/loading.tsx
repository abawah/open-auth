import { SiteLoadingIndicator } from "@/components/site-loading-indicator";

export default function Loading() {
  return <SiteLoadingIndicator />;
}
