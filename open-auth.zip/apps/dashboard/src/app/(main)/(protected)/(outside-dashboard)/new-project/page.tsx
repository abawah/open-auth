import PageClient from "./page-client";

export const metadata = {
  title: "New Project",
};

export default function Page () {
  return <PageClient />;
}
