import PageClient from "./page-client";

export const metadata = {
  title: "API Keys",
};

export default function Page() {
  return (
    <PageClient />
  );
}
