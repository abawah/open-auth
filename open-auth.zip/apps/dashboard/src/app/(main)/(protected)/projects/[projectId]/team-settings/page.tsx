import PageClient from "./page-client";

export const metadata = {
  title: "Team Settings",
};

export default function Page() {
  return (
    <PageClient />
  );
}
