import PageClient from "./page-client";

export const metadata = {
  title: "Users",
};

export default function Page() {
  return (
    <PageClient />
  );
}
