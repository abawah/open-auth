import PageClient from "./page-client";

export const metadata = {
  title: "Team Permissions",
};

export default function Page() {
  return (
    <PageClient />
  );
}
