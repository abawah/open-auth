import PageClient from "./page-client";

export const metadata = {
  title: "Domains",
};

export default function Page() {
  return (
    <PageClient />
  );
}
