import PageClient from "./page-client";

export const metadata = {
  title: "Teams",
};

export default function Page() {
  return (
    <PageClient />
  );
}
