import PageClient from "./page-client";

export const metadata = {
  title: "Emails",
};

export default function Page() {
  return (
    <PageClient />
  );
}
