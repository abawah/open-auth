import PageClient from "./page-client";

export const metadata = {
  title: "Auth Settings",
};

export default function Page() {
  return (
    <PageClient />
  );
}
