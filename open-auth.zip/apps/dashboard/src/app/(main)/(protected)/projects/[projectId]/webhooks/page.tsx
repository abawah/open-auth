import PageClient from "./page-client";

export const metadata = {
  title: "Webhooks",
};

export default function Page() {
  return (
    <PageClient />
  );
}
