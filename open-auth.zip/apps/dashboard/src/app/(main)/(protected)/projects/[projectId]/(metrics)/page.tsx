import PageClient from "./page-client";

export const metadata = {
  title: "Dashboard",
};

export default function Page() {
  return (
    <PageClient />
  );
}
