# @stackframe/docs

## 2.7.28

## 2.7.27

### Patch Changes

- Various changes

## 2.7.26

### Patch Changes

- Various changes

## 2.7.25

### Patch Changes

- Various changes

## 2.7.24

### Patch Changes

- Various changes

## 2.7.23

### Patch Changes

- Various changes

## 2.7.22

### Patch Changes

- Various changes

## 2.7.21

### Patch Changes

- Various changes

## 2.7.20

## 2.7.19

## 2.7.18

### Patch Changes

- Various changes

## 2.7.17

### Patch Changes

- Various changes

## 2.7.16

### Patch Changes

- Various changes

## 2.7.15

## 2.7.14

## 2.7.13

### Patch Changes

- Various changes

## 2.7.12

### Patch Changes

- Various changes

## 2.7.11

## 2.7.10

### Patch Changes

- Various changes

## 2.7.9

## 2.7.8

### Patch Changes

- Various changes

## 2.7.7

## 2.7.6

### Patch Changes

- Fixed bugs, updated Neon requirements

## 2.7.5

### Patch Changes

- Various changes

## 2.7.4

## 2.7.3

## 2.7.2

## 2.7.1

## 2.7.0

## 2.6.39

## 2.6.38

### Patch Changes

- Various changes

## 2.6.37

## 2.6.36

## 2.6.35

## 2.6.34

### Patch Changes

- Bugfixes

## 2.6.33

## 2.6.32

## 2.6.31

### Patch Changes

- Bugfixes

## 2.6.30

### Patch Changes

- Bugfixes

## 2.6.29

### Patch Changes

- Bugfixes

## 2.6.28

## 2.6.27

### Patch Changes

- Bugfixes

## 2.6.26

### Patch Changes

- Various bugfixes

## 2.6.25

### Patch Changes

- Translation overrides

## 2.6.24

### Patch Changes

- Bugfixes

## 2.6.23

### Patch Changes

- Bugfixes

## 2.6.22

### Patch Changes

- Bugfixes

## 2.6.21

### Patch Changes

- Fixed inviteUser

## 2.6.20

### Patch Changes

- Next.js 15 fixes

## 2.6.19

### Patch Changes

- Bugfixes

## 2.6.18

### Patch Changes

- fixed user update bug

## 2.6.17

### Patch Changes

- Loading skeletons

## 2.6.16

### Patch Changes

- - list user pagination
  - fixed visual glitches

## 2.6.15

## 2.6.14

## 2.6.13

### Patch Changes

- Updated docs

## 2.6.12

### Patch Changes

- Updated account settings page

## 2.6.11

### Patch Changes

- fixed account settings bugs

## 2.6.10

### Patch Changes

- Various bugfixes

## 2.6.9

### Patch Changes

- - New contact channel API
  - Fixed some visual gitches and typos
  - Bug fixes

## 2.6.8

## 2.6.7

## 2.6.6

## 2.6.5

### Patch Changes

- Minor improvements

## 2.6.4

### Patch Changes

- fixed small problems

## 2.6.3

## 2.6.2

### Patch Changes

- Several bugfixes & typos

## 2.6.1

### Patch Changes

- Bugfixes

## 2.6.0

### Minor Changes

- OTP login, more providers, and styling improvements

## 2.5.37

### Patch Changes

- client side account deletion; new account setting style;

## 2.5.36

### Patch Changes

- added apple oauth

## 2.5.35

### Patch Changes

- Doc improvements

## 2.5.34

### Patch Changes

- Internationalization

## 2.5.33

### Patch Changes

- Team membership webhooks

## 2.5.32

## 2.5.31

### Patch Changes

- JWKS

## 2.5.30

### Patch Changes

- More OAuth providers

## 2.5.29

## 2.5.28

### Patch Changes

- Bugfixes

## 2.5.27

### Patch Changes

- Bugfixes

## 2.5.26

### Patch Changes

- Bugfixes

## 2.5.25

### Patch Changes

- GitLab OAuth provider

## 2.5.24

## 2.5.23

### Patch Changes

- Various bugfixes and performance improvements

## 2.5.22

### Patch Changes

- Team metadata

## 2.5.21

### Patch Changes

- Discord OAuth provider

## 2.5.20

### Patch Changes

- Improved account settings

## 2.5.19

### Patch Changes

- Team frontend components

## 2.5.18

### Patch Changes

- Multi-factor authentication

## 2.5.17

## 2.5.16

## 2.5.15

### Patch Changes

- Webhooks

## 2.5.14

### Patch Changes

- added oauth token table

## 2.5.13

## 2.5.12

## 2.5.11

## 2.5.10

### Patch Changes

- Facebook Business support

## 2.5.9

### Patch Changes

- Impersonation

## 2.5.8

### Patch Changes

- Improved docs

## 2.5.7

## 2.5.6

## 2.5.5

## 2.5.4

### Patch Changes

- Backend rework

## 2.5.3

### Patch Changes

- Updated dependencies
  - @stackframe/stack-backend@2.5.3

## 2.5.2

### Patch Changes

- Updated dependencies
  - @stackframe/stack-backend@2.5.2

## 2.5.1

### Patch Changes

- New backend endpoints
- Updated dependencies
  - @stackframe/stack-backend@2.5.1

## 2.5.0

### Minor Changes

- Client teams and many bugfixes

### Patch Changes

- Updated dependencies
  - @stackframe/stack-backend@2.5.0

## 2.4.28

### Patch Changes

- Bugfixes
- Updated dependencies
  - @stackframe/stack-backend@2.4.28

## 2.4.27

### Patch Changes

- @stackframe/stack-server@2.4.27

## 2.4.26

### Patch Changes

- Improve docs
- Updated dependencies
  - @stackframe/stack-server@2.4.26

## 2.4.25

### Patch Changes

- Docs update
