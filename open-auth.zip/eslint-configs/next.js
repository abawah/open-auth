module.exports = {
  extends: [
    "next/core-web-vitals",
  ],
  rules: {
    "react/jsx-indent": ["error", 2],
  },
};
