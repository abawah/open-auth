declare const Home: (props: any) => JSX.Element;
export default Home;
