declare const Handler: (props: any) => JSX.Element;
export default Handler;
